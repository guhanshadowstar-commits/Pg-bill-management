# PG Electricity Bill Management System

A complete working app for fair PG electricity split billing by occupancy days.

## Works Out-of-the-Box
This build runs immediately with local persistent data (`data/db.json`) and requires no external setup.

## Run
```bash
npm install
npm run dev
```
Open [http://localhost:3000](http://localhost:3000)

## Core Formula
`Individual Bill = (Days Stayed / Total Person-Days) * Total Electricity Bill`

## Included Features
- Dashboard analytics
- Room management
- Tenant management
- Occupancy logging (check-in/check-out)
- Bill calculation and saving
- Payment status tracking
- AI occupancy parser endpoint
- Notification payload endpoint for reminders
- Premium responsive interface (dark/light)

## Supabase Ready
`supabase/schema.sql` and `supabase/seed.sql` are included for migration to Supabase.

## n8n Ready
Workflow JSON is included in `n8n/workflows/` for monthly reminders.
