import { NextResponse } from "next/server";
import { calculateBillSplit } from "@/lib/billing";
import { readDb } from "@/lib/db";

export async function POST(req: Request) {
  const body = await req.json();
  const { roomNumber, month, totalBill } = body as { roomNumber: string; month: string; totalBill: number };

  const db = await readDb();
  const room = db.rooms.find((r) => r.room_number === roomNumber);
  if (!room) return NextResponse.json({ error: "Room not found" }, { status: 404 });

  const logs = db.occupancy_logs
    .filter((o) => o.room_id === room.id)
    .map((o) => ({
      tenantId: o.tenant_id,
      tenantName: db.tenants.find((t) => t.id === o.tenant_id)?.full_name || "Unknown",
      checkIn: o.check_in,
      checkOut: o.check_out
    }));

  const result = calculateBillSplit({ totalBill, roomNumber, month, logs });
  return NextResponse.json(result);
}
