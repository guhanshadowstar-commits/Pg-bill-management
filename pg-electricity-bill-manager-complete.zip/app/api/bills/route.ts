import { NextResponse } from "next/server";
import { calculateBillSplit } from "@/lib/billing";
import { readDb, writeDb } from "@/lib/db";
import { uid } from "@/lib/utils";

export async function GET() {
  const db = await readDb();

  const rows = [...db.electricity_bills]
    .sort((a, b) => b.bill_month.localeCompare(a.bill_month))
    .map((bill) => ({
      ...bill,
      rooms: { room_number: db.rooms.find((r) => r.id === bill.room_id)?.room_number || "-" },
      bill_splits: db.bill_splits
        .filter((s) => s.bill_id === bill.id)
        .map((s) => ({
          ...s,
          tenants: { full_name: db.tenants.find((t) => t.id === s.tenant_id)?.full_name || "-" }
        }))
    }));

  return NextResponse.json(rows);
}

export async function POST(req: Request) {
  const body = await req.json();
  const { roomNumber, month, totalBill } = body as { roomNumber: string; month: string; totalBill: number };

  const db = await readDb();
  const room = db.rooms.find((r) => r.room_number === roomNumber);
  if (!room) return NextResponse.json({ error: "Room not found" }, { status: 404 });

  const logs = db.occupancy_logs
    .filter((o) => o.room_id === room.id)
    .map((o) => ({
      tenantId: o.tenant_id,
      tenantName: db.tenants.find((t) => t.id === o.tenant_id)?.full_name || "Unknown",
      checkIn: o.check_in,
      checkOut: o.check_out
    }));

  const calc = calculateBillSplit({ totalBill, month, roomNumber, logs });

  const existing = db.electricity_bills.find((b) => b.room_id === room.id && b.bill_month === month);
  const billId = existing?.id || uid("bill");

  db.electricity_bills = db.electricity_bills.filter((b) => !(b.room_id === room.id && b.bill_month === month));
  db.electricity_bills.push({
    id: billId,
    room_id: room.id,
    bill_month: month,
    total_amount: totalBill,
    total_person_days: calc.totalPersonDays,
    per_person_day_cost: calc.perPersonDayCost,
    created_at: new Date().toISOString()
  });

  db.bill_splits = db.bill_splits.filter((s) => s.bill_id !== billId);
  for (const split of calc.splits) {
    db.bill_splits.push({
      id: uid("split"),
      bill_id: billId,
      tenant_id: split.tenantId,
      days_stayed: split.daysStayed,
      amount: split.amount,
      status: "pending",
      created_at: new Date().toISOString()
    });
  }

  await writeDb(db);
  return NextResponse.json({ ...calc, billId, saved: true });
}
