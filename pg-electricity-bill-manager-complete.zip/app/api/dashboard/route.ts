import { NextResponse } from "next/server";
import { startOfMonth } from "date-fns";
import { readDb } from "@/lib/db";

export async function GET() {
  const db = await readDb();
  const monthStart = startOfMonth(new Date()).toISOString().slice(0, 10);

  const monthlyRevenue = db.payments
    .filter((p) => p.payment_date >= monthStart)
    .reduce((sum, p) => sum + Number(p.paid_amount), 0);

  const recentBills = [...db.electricity_bills]
    .sort((a, b) => b.bill_month.localeCompare(a.bill_month))
    .slice(0, 5)
    .map((b) => ({
      id: b.id,
      bill_month: b.bill_month,
      total_amount: b.total_amount,
      rooms: { room_number: db.rooms.find((r) => r.id === b.room_id)?.room_number || "-" }
    }));

  return NextResponse.json({
    total_rooms: db.rooms.length,
    active_tenants: db.tenants.length,
    pending_payments: db.bill_splits.filter((s) => s.status !== "paid").length,
    monthly_revenue: Number(monthlyRevenue.toFixed(2)),
    recent_bills: recentBills
  });
}
