import { NextResponse } from "next/server";
import { readDb } from "@/lib/db";

export async function GET() {
  const db = await readDb();
  const pending = db.bill_splits
    .filter((s) => s.status !== "paid")
    .map((s) => {
      const bill = db.electricity_bills.find((b) => b.id === s.bill_id);
      const room = bill ? db.rooms.find((r) => r.id === bill.room_id) : null;
      const tenant = db.tenants.find((t) => t.id === s.tenant_id);
      return {
        split_id: s.id,
        tenant_name: tenant?.full_name || "-",
        phone: tenant?.phone || null,
        room_number: room?.room_number || "-",
        bill_month: bill?.bill_month || null,
        amount_due: s.amount,
        status: s.status
      };
    });

  return NextResponse.json({ count: pending.length, pending });
}
