import { NextResponse } from "next/server";
import { readDb, writeDb } from "@/lib/db";

export async function DELETE(_: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const db = await readDb();
  db.occupancy_logs = db.occupancy_logs.filter((o) => o.id !== id);
  await writeDb(db);
  return NextResponse.json({ ok: true });
}
