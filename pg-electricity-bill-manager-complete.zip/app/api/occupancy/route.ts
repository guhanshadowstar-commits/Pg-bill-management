import { NextResponse } from "next/server";
import { readDb, writeDb } from "@/lib/db";
import { uid } from "@/lib/utils";

export async function GET() {
  const db = await readDb();

  const rows = db.occupancy_logs
    .map((o) => ({
      ...o,
      rooms: { room_number: db.rooms.find((r) => r.id === o.room_id)?.room_number || "-" },
      tenants: { full_name: db.tenants.find((t) => t.id === o.tenant_id)?.full_name || "-" }
    }))
    .sort((a, b) => b.check_in.localeCompare(a.check_in));

  return NextResponse.json(rows);
}

export async function POST(req: Request) {
  const body = await req.json();
  const db = await readDb();

  const row = {
    id: uid("occ"),
    room_id: String(body.room_id),
    tenant_id: String(body.tenant_id),
    check_in: String(body.check_in),
    check_out: body.check_out || null,
    created_at: new Date().toISOString()
  };

  db.occupancy_logs.push(row);
  await writeDb(db);
  return NextResponse.json(row, { status: 201 });
}
