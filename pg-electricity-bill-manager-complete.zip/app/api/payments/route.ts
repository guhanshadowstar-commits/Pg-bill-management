import { NextResponse } from "next/server";
import { readDb, writeDb } from "@/lib/db";
import { uid } from "@/lib/utils";

export async function POST(req: Request) {
  const body = await req.json();
  const { billSplitId, paidAmount, method = "cash", txnRef = null } = body as {
    billSplitId: string;
    paidAmount: number;
    method?: string;
    txnRef?: string | null;
  };

  const db = await readDb();
  const split = db.bill_splits.find((s) => s.id === billSplitId);
  if (!split) return NextResponse.json({ error: "Bill split not found" }, { status: 404 });

  db.payments.push({
    id: uid("pay"),
    bill_split_id: billSplitId,
    paid_amount: Number(paidAmount),
    payment_date: new Date().toISOString().slice(0, 10),
    status: "pending",
    method,
    txn_ref: txnRef,
    created_at: new Date().toISOString()
  });

  const totalPaid = db.payments
    .filter((p) => p.bill_split_id === billSplitId)
    .reduce((sum, p) => sum + Number(p.paid_amount || 0), 0);

  split.status = totalPaid >= split.amount ? "paid" : totalPaid > 0 ? "partial" : "pending";

  const tenant = db.tenants.find((t) => t.id === split.tenant_id);
  if (tenant) tenant.payment_status = split.status;

  await writeDb(db);
  return NextResponse.json({ ok: true, status: split.status, totalPaid, dueAmount: split.amount });
}
