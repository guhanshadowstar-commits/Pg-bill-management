import { NextResponse } from "next/server";
import { readDb, writeDb } from "@/lib/db";
import { uid } from "@/lib/utils";

export async function GET() {
  const db = await readDb();
  const rows = [...db.rooms].sort((a, b) => a.room_number.localeCompare(b.room_number));
  return NextResponse.json(rows);
}

export async function POST(req: Request) {
  const body = await req.json();
  const db = await readDb();
  const status: "active" | "inactive" = body.status === "inactive" ? "inactive" : "active";

  if (db.rooms.some((r) => r.room_number === body.room_number)) {
    return NextResponse.json({ error: "Room number already exists" }, { status: 400 });
  }

  const row = {
    id: uid("room"),
    room_number: String(body.room_number),
    sharing_type: Number(body.sharing_type || 1),
    meter_number: body.meter_number || null,
    status,
    created_at: new Date().toISOString()
  };

  db.rooms.push(row);
  await writeDb(db);
  return NextResponse.json(row, { status: 201 });
}
