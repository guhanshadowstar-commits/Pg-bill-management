import { NextResponse } from "next/server";
import { readDb, writeDb } from "@/lib/db";

export async function PUT(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const body = await req.json();
  const db = await readDb();
  const idx = db.tenants.findIndex((r) => r.id === id);

  if (idx === -1) return NextResponse.json({ error: "Tenant not found" }, { status: 404 });

  db.tenants[idx] = { ...db.tenants[idx], ...body };
  await writeDb(db);
  return NextResponse.json(db.tenants[idx]);
}
