import { NextResponse } from "next/server";
import { readDb, writeDb } from "@/lib/db";
import { uid } from "@/lib/utils";

export async function GET() {
  const db = await readDb();
  return NextResponse.json([...db.tenants].sort((a, b) => b.created_at.localeCompare(a.created_at)));
}

export async function POST(req: Request) {
  const body = await req.json();
  const db = await readDb();

  const row = {
    id: uid("tenant"),
    full_name: String(body.full_name),
    phone: body.phone || null,
    payment_status: "pending" as const,
    created_at: new Date().toISOString()
  };

  db.tenants.push(row);
  await writeDb(db);
  return NextResponse.json(row, { status: 201 });
}
